package br.com.mirapersonalizada

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class CrosshairService : Service() {
    private lateinit var windowManager: WindowManager
    private var crosshair: CrosshairView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_UPDATE -> {
                val s = intent.getIntExtra("size", 48)
                val t = intent.getIntExtra("thickness", 4)
                val c = intent.getIntExtra("color", 0xFF00FF00.toInt())
                crosshair?.setValues(s, t, c)
                if (crosshair == null) show(s, t, c)
            }
            else -> {
                val s = intent?.getIntExtra("size", 48) ?: 48
                val t = intent?.getIntExtra("thickness", 4) ?: 4
                val c = intent?.getIntExtra("color", 0xFF00FF00.toInt()) ?: 0xFF00FF00.toInt()
                show(s, t, c)
            }
        }
        return START_NOT_STICKY
    }

    private fun show(size: Int, thickness: Int, color: Int) {
        if (crosshair != null) {
            crosshair?.setValues(size, thickness, color)
            return
        }
        val view = CrosshairView(this).apply {
            setValues(size, thickness, color)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            180, 180, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = 0
            y = 0
        }
        windowManager.addView(view, params)
        crosshair = view
    }

    override fun onDestroy() {
        crosshair?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        crosshair = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_SHOW = "br.com.mirapersonalizada.SHOW"
        const val ACTION_UPDATE = "br.com.mirapersonalizada.UPDATE"
    }
}
