# Mira Personalizada (Android)

Projeto simples em Kotlin para Android: permite testar uma mira e, opcionalmente, mostrar uma sobreposição flutuante ajustável. Ele não modifica arquivos do Free Fire nem interage com a memória do jogo.

## Requisitos
- Android Studio recente
- JDK 17 (normalmente incluído no Android Studio)
- Android SDK 35 instalado pelo SDK Manager

## Como abrir
1. Extraia o ZIP.
2. No Android Studio, escolha **Open** e selecione a pasta `MiraPersonalizada`.
3. Aguarde a sincronização do Gradle.
4. Se o Android Studio pedir para instalar componentes do SDK, aceite.

## Como gerar o APK de teste
1. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
2. Quando terminar, clique em **locate** na notificação.
3. O APK de debug normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.
4. Copie o APK para o celular e abra-o para instalar. Talvez seja necessário permitir instalação desta fonte nas configurações do Android.

## Como usar
1. Abra o app.
2. Ajuste tamanho e espessura; use **Mudar cor** para alternar a cor.
3. Toque em **Ativar mira flutuante** e conceda a permissão de sobreposição nas configurações do Android.
4. Para remover, volte ao app e toque em **Desativar mira flutuante**.

## Observações
- A sobreposição pode ser bloqueada, ocultada ou causar incompatibilidade em alguns jogos, dependendo da versão do Android e das regras do jogo.
- Use apenas onde overlays são permitidos. Não há promessa de compatibilidade com Free Fire nem de que o jogo permitirá a sobreposição.
- Para gerar um APK de lançamento assinado, use **Build > Generate Signed Bundle / APK** e crie uma chave de assinatura que você guarde em segurança.
