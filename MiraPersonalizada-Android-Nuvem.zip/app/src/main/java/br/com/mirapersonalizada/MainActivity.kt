package br.com.mirapersonalizada

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private var size = 48
    private var thickness = 4
    private var colorIndex = 0
    private val colors = intArrayOf(Color.GREEN, Color.CYAN, Color.RED, Color.WHITE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 28, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "Mira Personalizada"
            textSize = 24f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Ajuste a mira e teste a aparência. A sobreposição pode não funcionar em todos os jogos."
            textSize = 14f
            setPadding(0, 12, 0, 16)
        })
        val preview = CrosshairView(this).apply {
            setValues(size, thickness, colors[colorIndex])
        }
        root.addView(preview, LinearLayout.LayoutParams(220, 180))

        root.addView(TextView(this).apply { text = "Tamanho da mira"; textSize = 16f })
        val sizeBar = SeekBar(this).apply {
            max = 100
            progress = size - 10
        }
        root.addView(sizeBar)
        sizeBar.setOnSeekBarChangeListener(simpleListener {
            size = it + 10
            preview.setValues(size, thickness, colors[colorIndex])
            updateOverlayIfRunning()
        })

        root.addView(TextView(this).apply { text = "Espessura"; textSize = 16f })
        val thickBar = SeekBar(this).apply {
            max = 10
            progress = thickness - 1
        }
        root.addView(thickBar)
        thickBar.setOnSeekBarChangeListener(simpleListener {
            thickness = it + 1
            preview.setValues(size, thickness, colors[colorIndex])
            updateOverlayIfRunning()
        })

        root.addView(Button(this).apply {
            text = "Mudar cor"
            setOnClickListener {
                colorIndex = (colorIndex + 1) % colors.size
                preview.setValues(size, thickness, colors[colorIndex])
                updateOverlayIfRunning()
            }
        })
        root.addView(Button(this).apply {
            text = "Ativar mira flutuante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    val i = Intent(this@MainActivity, CrosshairService::class.java).apply {
                        action = CrosshairService.ACTION_SHOW
                        putExtra("size", size)
                        putExtra("thickness", thickness)
                        putExtra("color", colors[colorIndex])
                    }
                    startService(i)
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Desativar mira flutuante"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CrosshairService::class.java))
            }
        })
        setContentView(root)
    }

    private fun simpleListener(onProgress: (Int) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onProgress(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }

    private fun updateOverlayIfRunning() {
        val i = Intent(this, CrosshairService::class.java).apply {
            action = CrosshairService.ACTION_UPDATE
            putExtra("size", size)
            putExtra("thickness", thickness)
            putExtra("color", colors[colorIndex])
        }
        startService(i)
    }
}
