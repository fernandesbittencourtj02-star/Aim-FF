package br.com.mirapersonalizada

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class CrosshairView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var sizePx = 48
    private var thicknessPx = 4
    private var color = 0xFF00FF00.toInt()

    fun setValues(size: Int, thickness: Int, color: Int) {
        sizePx = size
        thicknessPx = thickness
        this.color = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        paint.color = color
        paint.strokeWidth = thicknessPx.toFloat()
        paint.strokeCap = Paint.Cap.ROUND
        val cx = width / 2f
        val cy = height / 2f
        val arm = sizePx / 2f
        val gap = sizePx / 7f
        canvas.drawLine(cx - arm, cy, cx - gap, cy, paint)
        canvas.drawLine(cx + gap, cy, cx + arm, cy, paint)
        canvas.drawLine(cx, cy - arm, cx, cy - gap, paint)
        canvas.drawLine(cx, cy + gap, cx, cy + arm, paint)
        canvas.drawCircle(cx, cy, thicknessPx / 1.5f, paint)
    }
}
